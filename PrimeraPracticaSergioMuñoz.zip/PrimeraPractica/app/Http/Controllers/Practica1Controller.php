<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Practica1Controller extends Controller
{
     private $mensajes = [
            
            'mensaje'=> 'Error, el usuario o la contraseña no son validos validos',
    ];
    
    
    function loginUser(Request $peticion, $mensaje = '') {
        $datos = [];
        if(isset($this->mensajes[$mensaje])) {
            $datos = [
                'mensaje'=> $this-> mensajes[$mensaje] 
            ];
        }
        return view('base.loginuser') -> with($datos);
    }
  
    
    function userhome(Request $request){

        $nombre = $request -> input('nombre');
        $clave = $request -> input('clave');
        if(strcasecmp($nombre,'pepe') === 0 && strcasecmp($clave,'pepe') === 0 ){
            return redirect('welcomeUser')->withInput($request -> except('clave'));
        }else{
            return redirect('loginuser/mensaje')->withInput($request -> except('clave'));

        }
        
    }
    function welcomeUser(Request $request){
        
         return view('base.bienvenidouser') ;
        
    }
     function forgotten(Request $request){
         return view('base.forgotten') ;
        
    }
    function redirectHome(Request $request){
         return view('base.home') ;
        
    }
    
    function home(){
        return view('base.home');
    }
    
    
    
    
    
    
    
    
    
    
   
}
