<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
        <meta name="generator" content="Jekyll v3.8.5">
        <title>Laravel</title>
        
    </head>
    <body>
        <main role="main">
            
            <div class="container">
                    <!--Contenido a rellenar-->
                    <?php echo $__env->yieldContent('contenido'); ?>
                    
            </div>
        </main>
        
    </body>
</html><?php /**PATH /home/ubuntu/environment/web/firstApp/resources/views/base.blade.php ENDPATH**/ ?>