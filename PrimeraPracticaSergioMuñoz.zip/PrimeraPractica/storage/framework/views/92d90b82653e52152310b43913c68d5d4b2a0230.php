<?php $__env->startSection('contenido'); ?>

<form action="<?php echo e(url('validate/doform')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input name="login" placeholder = "login required" type="text"  value=""/>
    <input name="mail" placeholder = "email required" type="text"  value=""/>
    <input name="password" placeholder = "password required" type="text"  value=""/>
    <input name="date" placeholder = "date required" type="text"  value=""/>
    <input type="submit" value="enviar"/>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/firstApp/resources/views/base/create.blade.php ENDPATH**/ ?>