
<?php $__env->startSection('contenido'); ?>


<?php if(isset($mensaje)): ?>
 <h2> <?php echo e($mensaje); ?> </h2>
<?php endif; ?>

<form action="<?php echo e(url('ruta16')); ?>" method="post">
<?php echo csrf_field(); ?>
    <input type="text" name="nombre" id="nombrefp" placeholder="nombre" required value="<?php echo e(old('nombre')); ?>">
    <input type="text" name="apellidos" id="apellidos" placeholder="apellidos" required value="<?php echo e(old('apellidos')); ?>">
    <input type="text" name="direccion" id="direccion" placeholder="dirección" value="<?php echo e(old('direccion')); ?>">
    <input type="email" name="correo" id="correo" placeholder="correo" value="<?php echo e(old('correo')); ?>">
    <input type="password" name="clave" id="clave" placeholder="clave" required value="<?php echo e(old('clave')); ?>">
    <input type="password" name="clave1" id="clave1" placeholder="clave1" required value="<?php echo e(old('clave1')); ?>">
    <input type="submit" value="enviar">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/firstApp/resources/views/base/ruta15.blade.php ENDPATH**/ ?>