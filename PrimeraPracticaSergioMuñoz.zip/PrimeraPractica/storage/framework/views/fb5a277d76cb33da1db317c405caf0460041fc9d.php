<?php $__env->startSection('contenido'); ?>


<img src="<?php echo e(url('ver/1')); ?>">

<form action="<?php echo e(url('upload')); ?>"                          method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="text" name="texto" value="texto1">
    <input type="file" name="file" id="file1">
    <input type="submit" value="enviar">
</form>

<form action="<?php echo e(action('FileUploadController@upload')); ?>"  method="post" enctype="multipart/form-data" >
    <?php echo csrf_field(); ?>
    <input type="text" name="texto" value="texto2">
    <input type="file" name="file" id="file2">
    <input type="submit" value="enviar">
</form>

<form action="<?php echo e(action('FileUploadController@upload')); ?>"  method="post" enctype="application/x-www-form-urlencoded" >
    <?php echo csrf_field(); ?>
    <input type="text" name="texto" value="texto3">
    <input type="file" name="file" id="file3">
    <input type="submit" value="enviar">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/firstApp/resources/views/base/subir.blade.php ENDPATH**/ ?>