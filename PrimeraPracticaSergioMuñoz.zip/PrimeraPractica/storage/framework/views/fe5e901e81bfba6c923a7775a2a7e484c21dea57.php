<?php $__env->startSection('contenido'); ?>


<?php if(isset($mensaje)): ?>
 <h2> <?php echo e($mensaje); ?> </h2>
<?php endif; ?>

<form action="<?php echo e(url('userhome')); ?>" method="post">
<?php echo csrf_field(); ?>
    <input type="text" name="nombre" id="nombrefp" placeholder="nombre" required value="<?php echo e(old('nombre')); ?>">
    <input type="password" name="clave" id="clave" placeholder="clave" required value="<?php echo e(old('clave')); ?>">
    <input type="submit" value="enviar">
</form>
<form action="<?php echo e(url('forgoten')); ?>" method="get">
  <input type="submit" value="Olvidaste la contraseña?">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/firstApp/resources/views/base/formulario.blade.php ENDPATH**/ ?>