<?php

Route::get('/', function () {
    return view('welcome');
});




Route::get('home/','Practica1Controller@home');
Route::any('userhome/','Practica1Controller@userhome');
Route::any('loginuser/{msj?}','Practica1Controller@loginuser');
Route::get('welcomeUser','Practica1Controller@welcomeUser');
Route::get('forgotten','Practica1Controller@forgotten');
Route::any('redirectHome/','Practica1Controller@redirectHome');




Route::fallback(function() {
    return '<h1>Error 404</h1>';
});